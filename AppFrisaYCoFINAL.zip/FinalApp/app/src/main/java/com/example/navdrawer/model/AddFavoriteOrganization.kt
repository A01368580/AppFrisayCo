package com.example.navdrawer.model

data class AddFavoriteOrganization(
  val userId: String?="",
  val organizationId: String?=""
)
