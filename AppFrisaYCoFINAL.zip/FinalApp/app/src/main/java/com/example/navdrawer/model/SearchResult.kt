package com.example.navdrawer.model

data class SearchResult(
    val selectedTags: List<String> = emptyList(),
    var organizations: List<OrganizationResponseItem> = emptyList()
)
