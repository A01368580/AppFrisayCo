package com.example.navdrawer.model

data class TagListItem(
    val tags : List<String>
)