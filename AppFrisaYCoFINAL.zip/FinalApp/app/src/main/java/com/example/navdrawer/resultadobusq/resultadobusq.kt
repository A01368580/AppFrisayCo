package com.example.navdrawer.screens.resultadobusq


import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.navdrawer.AppViewModel
import com.example.navdrawer.OrganizationViewModel.OrganizationViewModel
import com.example.navdrawer.screens.busquedatag.busquedatags
import com.example.navdrawer.ui.theme.BlancoGris
import com.example.navdrawer.ui.theme.GrisClaro
import com.example.navdrawer.ui.theme.RojoFrisa

@Composable
fun ResultadoBusqueda(
    navController: NavController,
    viewModel: AppViewModel,
    orgViewModel: OrganizationViewModel
) {
    Column(
        modifier = Modifier
            .background(GrisClaro)
            .fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        header()
        contenidoBusqueda(navController = navController, viewModel = viewModel,orgViewModel)
    }
}


@Composable
fun header(){
    Text(
        text = "Resultado de Búsqueda",
        style = TextStyle(
            fontSize = 20.sp,
            color = Color.Black,
            fontWeight = FontWeight.Bold
        ),
        modifier = Modifier
            //.padding(start = 20.dp)
            .padding(top = 20.dp)
    )
}

@Composable
fun contenidoBusqueda(
    navController: NavController,
    viewModel: AppViewModel,
    orgViewModel: OrganizationViewModel
) {
    LazyColumn(
        modifier = Modifier.padding(top = 10.dp).padding(start = 10.dp).padding(end = 10.dp),
        content = {
            items(items = orgViewModel.searchResultados.value.organizations) {organization->
                CardOrganizaciones(
                    orgname = organization.name, // Supongo que el nombre de la organización es relevante aquí
                    // Asegúrate de proporcionar la imagen de la organización de acuerdo a tu modelo de datos
                    organization.image
                ) { orgname ->
                    Log.d("Organizaciones", "$orgname")
                    navController.navigate("detalles/$orgname")
                }
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CardOrganizaciones(
    orgname: String,
    imageUrl: String,
    onItemClick: (String) -> Unit = {}
) {
    FlowRow {
        Card(
            modifier = Modifier
                .padding(10.dp)
                .width(287.dp)
                .height(250.dp)
                .clickable {
                    onItemClick(orgname)
                },
            colors = CardDefaults.cardColors(containerColor = BlancoGris),
            shape = RoundedCornerShape(20.dp),
        ) {
            Column(
                //horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BlancoGris)
                ) {
                    // Imagen de la organización
                    AsyncImage(model = imageUrl, contentDescription = null)
                }
                Column(
                    modifier = Modifier.padding(8.dp)
                ) {
                    Text(
                        text = orgname,
                        style = TextStyle(
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = RojoFrisa,
                            textAlign = TextAlign.Justify
                        ),
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
            }
        }
    }
}