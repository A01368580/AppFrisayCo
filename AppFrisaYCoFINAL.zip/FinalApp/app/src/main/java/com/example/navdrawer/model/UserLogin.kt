package com.example.navdrawer.model


data class UserLogin(
    val phone:  String, // Puede ser nulo
    val password: String
)