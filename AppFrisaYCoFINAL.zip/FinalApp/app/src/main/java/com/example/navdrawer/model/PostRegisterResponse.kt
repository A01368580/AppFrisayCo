package com.example.navdrawer.model

data class PostRegisterResponse(
    val title: String?="",
    val content: String?="",
    val image: String?="",
    //val user: String?="",
    val date: String?=""
)
