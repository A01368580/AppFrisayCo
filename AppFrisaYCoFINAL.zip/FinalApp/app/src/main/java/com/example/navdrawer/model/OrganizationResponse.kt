package com.example.navdrawer.model

class OrganizationResponse : ArrayList<OrganizationResponseItem>()