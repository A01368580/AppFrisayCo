package com.example.navdrawer.model

data class OrgRegisterResponse(
    val token: String?="",
    val id: String?="",
    val name: String?=""
    // Add other fields specific to the organization schema as needed
)
