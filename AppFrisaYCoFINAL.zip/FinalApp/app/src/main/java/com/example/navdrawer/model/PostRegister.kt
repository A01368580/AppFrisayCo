package com.example.navdrawer.model

data class PostRegister(
    val title: String?="",
    val content: String?="",
    val image: String?="",
    //val user: String?=""
)
