package com.example.navdrawer.model

data class FindTags(
    val tags: List<String> = emptyList()
)