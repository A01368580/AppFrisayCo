package com.example.navdrawer.model

data class PostsGetAllItem(
    val __v: Int,
    val _id: String,
    val content: String,
    val date: String,
    val image: String,
    val title: String
)