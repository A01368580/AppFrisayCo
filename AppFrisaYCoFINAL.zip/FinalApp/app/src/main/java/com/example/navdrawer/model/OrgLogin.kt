package com.example.navdrawer.model

data class OrgLogin(
    val phone: String?="",
    val password: String?=""
)
