package com.example.navdrawer.model

class TagsList : ArrayList<String>() {

}