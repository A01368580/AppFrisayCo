package com.example.navdrawer.OrganizationViewModel

import android.util.Log
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.navdrawer.model.FindTags
import com.example.navdrawer.model.GetAllFavorites
import com.example.navdrawer.model.OrganizationResponse
import com.example.navdrawer.model.PostsGetAll
import com.example.navdrawer.model.SearchResult
import com.example.navdrawer.model.TagsList
import com.example.navdrawer.service.OrgService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class OrganizationViewModel(private val orgService: OrgService) : ViewModel() {





    private val _getAllFavorites = MutableStateFlow<GetAllFavorites?>(null)
    val getAllFavorites: StateFlow<GetAllFavorites?> = _getAllFavorites

    private val _getOrgResult = MutableStateFlow<OrganizationResponse?>(null)
    val getOrgResult: StateFlow<OrganizationResponse?> = _getOrgResult

    private val _getAllPosts = MutableStateFlow<PostsGetAll?>(null)
    val getAllPosts: StateFlow<PostsGetAll?> = _getAllPosts

    private val _getAllTags = MutableStateFlow<TagsList?>(null)
    val getAllTags: StateFlow<TagsList?> = _getAllTags


    private val _findbytags = MutableStateFlow<TagsList?>(null)
    val findbytags: StateFlow<TagsList?> = _findbytags

    private val _findOrganizationsByTags = MutableStateFlow<TagsList?>(null)
    val findOrganizationsByTags: StateFlow<TagsList?> = _findOrganizationsByTags

    private val _searchResult = MutableStateFlow<SearchResult?>(null)
    val searchResult: StateFlow<SearchResult?> = _searchResult


    var selectedTags = mutableStateOf(mutableListOf<String>())

    var searchResultados = mutableStateOf(SearchResult())

    fun getUserFavoriteOrganization() {
        viewModelScope.launch {
            val response: OrganizationResponse

            try {
                response = orgService.getAllOrgs()
                _getOrgResult.value = response
            } catch (e: Exception) {

                val errorResponse = e.localizedMessage
                Log.d("ERROR-API", errorResponse)
                //_getUserFavoriteOrgsResult.value = errorResponse
            }
        }
    }

    fun getAllFavorites(userId:String){
        viewModelScope.launch {
            val response: GetAllFavorites

            try {
                response = orgService.getAllFavorites(userId)
                _getAllFavorites.value = response
            } catch (e: Exception) {

                val errorResponse = e.localizedMessage
                Log.d("ERROR-API", errorResponse)
                //_getUserFavoriteOrgsResult.value = errorResponse
            }
        }
    }

    fun getAllPosts(){
        viewModelScope.launch {
            val response: PostsGetAll

            try {
                response = orgService.getAllPosts()
                _getAllPosts.value = response
            } catch (e: Exception) {

                val errorResponse = e.localizedMessage
                Log.d("ERROR-API", errorResponse)
                //_getUserFavoriteOrgsResult.value = errorResponse
            }
        }
    }

    fun getAllTags(){
        viewModelScope.launch {
            val response: TagsList

            try {
                response = orgService.getAllTags()
                _getAllTags.value = response
            } catch (e: Exception) {

                val errorResponse = e.localizedMessage
                Log.d("ERROR-API", errorResponse)
                //_getUserFavoriteOrgsResult.value = errorResponse
            }
        }
    }

    fun findbyTagsOrg(tags: List<String>) {
        viewModelScope.launch {
            try {
                Log.d("LISTA2", tags.toString())
                val tagList = FindTags(tags)
                Log.d("LISTA3", tagList.toString())

                val response = orgService.findbytags(tagList)


                // Log the response body if it's not null
                Log.d("API Response", response.toString())

                // Create a SearchResult object to store selected tags and response data
                val searchResult = SearchResult(tags, response)
                selectedTags.value.addAll(tags)
                searchResultados.value = searchResult
                _searchResult.value =   searchResult
                //_searchResult.value = searchResult

            } catch (e: Exception) {
                val errorResponse = e.localizedMessage
                Log.d("ERROR-API", errorResponse)
            }
        }
    }







}