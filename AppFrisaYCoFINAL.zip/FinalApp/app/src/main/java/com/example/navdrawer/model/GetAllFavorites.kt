package com.example.navdrawer.model

class GetAllFavorites : ArrayList<Favorite>()