package com.example.navdrawer.model

data class GetFavoriteOrganizationResponseItem(
    val _id:String
)
