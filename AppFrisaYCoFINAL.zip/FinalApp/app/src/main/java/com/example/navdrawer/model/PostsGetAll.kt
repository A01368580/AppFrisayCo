package com.example.navdrawer.model

class PostsGetAll : ArrayList<PostsGetAllItem>()