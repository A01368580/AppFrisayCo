package com.example.navdrawer.model
class GetFavoriteOrganizationResponse: ArrayList<GetFavoriteOrganizationResponseItem>()
